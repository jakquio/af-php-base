
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<title></title>
</head>

<body>

<?php

echo <<<HTML

<div align='center'>
<form action = 'logout.php' method = 'post' >
	<input type='submit' name = 'logout' value = 'Sign Out' />
</form>
</div>

HTML;
?>

</body>
</html>
