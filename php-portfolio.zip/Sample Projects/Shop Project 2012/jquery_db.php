<table cellspacing='0'>
<thead>
  <tr>
    <th>Name</th>
    <th>Address</th>
    <th>City</th>
  </tr>
</thead>
<tbody>    <tr>
      <td>Bunny, Bugs</td>
      <td>5522 Carrot Top Blvd.</td>
      <td>San Antonio, TX 78212</td>
    </tr>    <tr>
      <td>Duck, Daffy</td>
      <td>345 Duck Pond Lane</td>
      <td>San Antonio, TX 78230</td>
    </tr>    <tr>
      <td>Flintstone, Fred</td>
      <td>1890 Quarry Road</td>
      <td>San Antonio, TX 78212</td>
    </tr>    <tr>
      <td>Fred, Farmer</td>
      <td>145 Halloween Drive</td>
      <td>Alice, TX 78299</td>
    </tr>    <tr>
      <td>Keaton, Buster</td>
      <td>3456 Cemetery Row</td>
      <td>Fair Lawn, CA 99123</td>
    </tr>    <tr>
      <td>O'Bob, Jr., Dr. Billy</td>
      <td>123-1/2 Corncob, #1A</td>
      <td>San Antonio, TX 78229</td>
    </tr>    <tr>
      <td>Ogre, Shrek the</td>
      <td>12 Swamp Lane</td>
      <td>San Antonio, TX 78212</td>
    </tr>    <tr>
      <td>Rubble, Barney</td>
      <td>1892 Quarry Road</td>
      <td>San Antonio, TX 78212</td>
    </tr>    <tr>
      <td>User, Demo</td>
      <td>1234 Five Lane</td>
      <td>Anytown, TX 78212</td>
    </tr>    <tr>
      <td>White, Snow</td>
      <td>234 Tiny Cove Lane</td>
      <td>San Antonio, TX 78212</td>
    </tr>    <tr>
      <td>Winkle, Bull</td>
      <td>102 Antler Lane</td>
      <td>San Antonio, TX 78212</td>
    </tr>    <tr>
      <td>Zollars, Dan</td>
      <td>San Antonio College</td>
      <td>San Antonio, TX 78212</td>
    </tr></tbody>
</table>