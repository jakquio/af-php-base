<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"html://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<title>Access Denied</title>
	<link href='style3-main.css' rel='stylesheet' type='text/css' />
</head>

<body>

<h3 class='center'>You do not have the power to see these page(s)!</h3>
	
<?php include 'link-main.php' ?>
	
 </body>
</html>
