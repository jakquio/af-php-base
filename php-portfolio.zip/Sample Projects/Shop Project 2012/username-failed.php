<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"html://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<title>Login Failure</title>
	<link href='style2-main.css' rel='stylesheet' type='text/css' />
</head>

<body class='bteal'>

<div class='center'>
	<h3>
		<br /> Log In Failed!! <br /> Please check your username and password.
	</h3>
	
<?php include 'include/link-main.php' ?>

</div>	

 </body>
</html>
