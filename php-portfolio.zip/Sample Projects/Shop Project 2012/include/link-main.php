

<?php

echo <<<HTML


<form action = 'login.php' >
		<p align='center'><input type = 'submit' name = 'submit' value = 'Return to Login Page'  /></p>
</form>

HTML;

?>