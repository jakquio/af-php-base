
<?php
	echo "
	
	<div align='center'>
	<form action ='register-form.php'>
		<p><input type='submit' name='register' value='Register Again!' /></p>
	</form>
	</div>
	
	";
?>