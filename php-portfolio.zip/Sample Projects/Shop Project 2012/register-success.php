
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">



<head>
	<title>User has been created!</title>
	<link href='style1-index.css' rel='stylesheet' type='text/css' />
</head>

<body>

<div class='center' id='header'>
<p> Thanks, you have created a new user!</p>
<p> You can now login using your email!</p>

<br />

<?php include 'include/link-main.php'; ?>

</body>
</html>